globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/3HbWHF2zxPK9Ta8TLMBJL/_buildManifest.js",
    "static/3HbWHF2zxPK9Ta8TLMBJL/_ssgManifest.js",
    "static/3HbWHF2zxPK9Ta8TLMBJL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0v5hay_63cf0e.js",
    "static/chunks/04pdrv52d4fz1.js",
    "static/chunks/0d95wy71fh0la.js",
    "static/chunks/0o~~~ml57d1q9.js",
    "static/chunks/13m-xasq1g3~f.js",
    "static/chunks/0ku4kf8bp5pc7.js",
    "static/chunks/turbopack-05fgs4rkdn.r..js"
  ]
};

var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/sync/route.js")
R.c("server/chunks/[root-of-the-server]__0nk31h2._.js")
R.c("server/chunks/0mv1_next_dist_esm_build_templates_app-route_09c~tnt.js")
R.c("server/chunks/[root-of-the-server]__13o7-ma._.js")
R.c("server/chunks/[root-of-the-server]__01v5if6._.js")
R.c("server/chunks/0mv1_next_dist_10r~9jy._.js")
R.c("server/chunks/0t_n_idea_apps_web__next-internal_server_app_api_users_sync_route_actions_0e4bk8l.js")
R.m(34572)
module.exports=R.m(34572).exports

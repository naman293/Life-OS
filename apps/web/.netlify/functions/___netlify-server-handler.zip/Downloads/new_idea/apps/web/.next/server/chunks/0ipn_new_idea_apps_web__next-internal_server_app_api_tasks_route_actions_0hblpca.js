module.exports=[94010,(e,o,d)=>{}];

//# sourceMappingURL=0ipn_new_idea_apps_web__next-internal_server_app_api_tasks_route_actions_0hblpca.js.map
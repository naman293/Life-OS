var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/habits/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0mccbe3._.js")
R.c("server/chunks/0mv1_next_dist_10r~9jy._.js")
R.c("server/chunks/0mv1_zod_v4_classic_external_0m9qla9.js")
R.c("server/chunks/[root-of-the-server]__01v5if6._.js")
R.c("server/chunks/[root-of-the-server]__13o7-ma._.js")
R.c("server/chunks/0t_n_idea_apps_web__next-internal_server_app_api_habits_[id]_route_actions_13s~0wn.js")
R.m(26690)
module.exports=R.m(26690).exports

module.exports=[15242,(e,o,d)=>{}];

//# sourceMappingURL=0t_n_idea_apps_web__next-internal_server_app_api_tasks_%5Bid%5D_route_actions_0ff_nay.js.map
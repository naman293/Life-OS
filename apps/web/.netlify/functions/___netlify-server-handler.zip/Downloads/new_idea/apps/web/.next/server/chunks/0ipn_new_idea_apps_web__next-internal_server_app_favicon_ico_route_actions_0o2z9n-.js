module.exports=[53685,(e,o,d)=>{}];

//# sourceMappingURL=0ipn_new_idea_apps_web__next-internal_server_app_favicon_ico_route_actions_0o2z9n-.js.map
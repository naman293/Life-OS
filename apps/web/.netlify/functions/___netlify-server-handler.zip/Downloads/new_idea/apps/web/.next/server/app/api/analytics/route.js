var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/route.js")
R.c("server/chunks/[root-of-the-server]__0_xy.kg._.js")
R.c("server/chunks/0mv1_next_dist_10r~9jy._.js")
R.c("server/chunks/[root-of-the-server]__13o7-ma._.js")
R.c("server/chunks/[root-of-the-server]__01v5if6._.js")
R.c("server/chunks/0ipn_new_idea_apps_web__next-internal_server_app_api_analytics_route_actions_06_r2sl.js")
R.m(13068)
module.exports=R.m(13068).exports

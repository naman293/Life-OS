module.exports=[12323,(a,b,c)=>{}];

//# sourceMappingURL=0ipn_new_idea_apps_web__next-internal_server_app__global-error_page_actions_08eisf2.js.map
module.exports=[63330,a=>{"use strict";var b=a.i(2686),c=a.i(85334);a.s(["default",0,function(){let a=(0,c.useTransitionStore)(a=>a.trigger),d=(0,b.useRef)(!1);return(0,b.useEffect)(()=>{d.current||(d.current=!0,a(0,0,420,460))},[]),null}])}];

//# sourceMappingURL=Downloads_new_idea_apps_web_src_app_transition_page_tsx_0-pdgxe._.js.map
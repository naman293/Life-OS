var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__0j~1vhv._.js")
R.c("server/chunks/[root-of-the-server]__0hz8ch2._.js")
R.c("server/chunks/0mv1_next_dist_0jr5c7.._.js")
R.m(79232)
module.exports=R.m(79232).exports

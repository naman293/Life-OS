module.exports=[83190,(e,o,d)=>{}];

//# sourceMappingURL=0t_n_idea_apps_web__next-internal_server_app_api_events_%5Bid%5D_route_actions_0q2gc4b.js.map
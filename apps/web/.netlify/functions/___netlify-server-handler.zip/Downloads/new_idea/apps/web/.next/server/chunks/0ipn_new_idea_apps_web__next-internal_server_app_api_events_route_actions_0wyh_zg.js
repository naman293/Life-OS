module.exports=[58431,(e,o,d)=>{}];

//# sourceMappingURL=0ipn_new_idea_apps_web__next-internal_server_app_api_events_route_actions_0wyh_zg.js.map
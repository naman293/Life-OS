var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0sqmaqd._.js")
R.c("server/chunks/0mv1_next_dist_esm_build_templates_app-route_0iwhs._.js")
R.c("server/chunks/0mv1_next_dist_0-dkwg3._.js")
R.c("server/chunks/[root-of-the-server]__13o7-ma._.js")
R.c("server/chunks/0ipn_new_idea_apps_web__next-internal_server_app_favicon_ico_route_actions_0o2z9n-.js")
R.m(11606)
module.exports=R.m(11606).exports

var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/events/route.js")
R.c("server/chunks/[root-of-the-server]__00hfhwf._.js")
R.c("server/chunks/0mv1_next_dist_10r~9jy._.js")
R.c("server/chunks/0mv1_zod_v4_classic_external_0m9qla9.js")
R.c("server/chunks/[root-of-the-server]__01v5if6._.js")
R.c("server/chunks/[root-of-the-server]__13o7-ma._.js")
R.c("server/chunks/0ipn_new_idea_apps_web__next-internal_server_app_api_events_route_actions_0wyh_zg.js")
R.m(6717)
module.exports=R.m(6717).exports

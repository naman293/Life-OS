module.exports=[64696,(e,o,d)=>{}];

//# sourceMappingURL=0ipn_new_idea_apps_web__next-internal_server_app_api_analytics_route_actions_06_r2sl.js.map